let str = "";
str = str.concat("2");
console.log(str);