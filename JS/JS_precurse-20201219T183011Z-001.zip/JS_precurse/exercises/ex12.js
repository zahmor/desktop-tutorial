const input = require('readline-sync');
let str = input.question("Please enter the string capitalize:");
let arr = str.split("");
function vowelCheck(c){
    if(c == 'a' || c=='e' || c=='i'|| c=='o' || c=='u' || c=='y'){
        return true;
    }
}
for(let i=0; i<arr.length; i+=1){
    if(vowelCheck(arr[i])){
        arr[i] = arr[i].toUpperCase();
    }
}
str = arr.join("");
console.log(str);