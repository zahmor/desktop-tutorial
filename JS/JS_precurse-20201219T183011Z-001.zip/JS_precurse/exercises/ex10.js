const input = require('readline-sync');
let str = input.question("what do you want to write? ");
let arr = str.split(" ");
str = arr.join("*");
console.log(str);

/* 
above I tried to use only what was in the video. 
here is another, simpler option, with a regular expression:

console.log(str.replace(/ /g, "*"));

*/