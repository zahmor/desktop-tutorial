const input = require('readline-sync');
let str = input.question("Please enter the string to check:  ");
boolPalindrom = false;
if(str == str.split("").reverse().join("")){
    boolPalindrom = true;
}
console.log(boolPalindrom);

/* 
palindrome - a "mirrored" string. 
*/