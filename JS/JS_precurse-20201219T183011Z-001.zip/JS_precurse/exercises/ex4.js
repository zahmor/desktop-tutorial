const readlineSync = require('readline-sync');

let people = readlineSync.question("How many people are you going with? ");
let boolKosher = readlineSync.keyInYNStrict("Should it be Kosher?");
let boolMehadrin = readlineSync.keyInYNStrict("should it be Kashrut Lemehadrin?");
let kosherRes = ["Cafe Halvah", "Nosh Garden", "Cafe Falafel", "Babka City", "Kosherology"];
let lamehadrinRes = ["Posh Pita", "Kosher Olive", "Nosh Palace", "Babka City", "Kosher Camembert"];
let notKosherRes = ["Shrimp house", "house of Pepperoni", "Bakon buffet", "Holy Smokes", "Sauce Bos"];

console.log("kosher?" + boolKosher + " mehadrin?"+boolMehadrin);
let resultArr = (boolKosher)? (boolMehadrin? lamehadrinRes: kosherRes):notKosherRes;
let index = readlineSync.keyInSelect(resultArr, 'which food do you like?');

if(index == -1 || isNaN(index)){
    throw new Error('exit program');
}
console.log(people + "are going to " + resultArr[index] + ". good choise");