let result = '';
for(let i = 0; i<=100; i+=1){
    if(i%7 === 0 || i.toString().search("7") > -1){
        result = result.concat("BOOM, ");
//        console.log("BOOM, ");
    } else {
        result = result.concat(i+",");
//        console.log(i+", ");
    }
}
console.log(result);

//edit: I could just use console log each iteration, but in the excersice the output was put in a single line -
// which is why I changed it to one long string.