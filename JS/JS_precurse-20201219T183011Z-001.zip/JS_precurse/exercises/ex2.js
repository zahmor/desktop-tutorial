

function sum(){
const input = require('readline-sync');
let num1 = Number(input.question("Enter the first number "));
let num2 = Number(input.question("Enter the second number "));
let answer = num1+num2 == 10? "makes 10": "nope";
console.log(answer);
}
sum();
