const input = require('readline-sync');
var name;
do {
    name = parseInt(input.question("Please choose a number larger than 10: "));
} while(name<=10);
console.log("Thank you");
