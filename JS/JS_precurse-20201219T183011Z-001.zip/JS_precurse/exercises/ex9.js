const input = require('readline-sync');

let num = input.question("What is the number? ");
let boolPrime = true;
for(let i = 2; i<num; i+=1){
    for(let j = 2; j<=Math.sqrt(i); j+=1){
        if (i%j===0){
            boolPrime = false;
            break;
        }
        boolPrime = true;
    } 
    if(boolPrime == true){
        console.log(i);
    }
    }
