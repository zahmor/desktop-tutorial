const input = require('readline-sync');

let num = parseInt(input.question("please enter a positive number: "));
let factorial = 1
for(let i = 1; i<num+1; i+=1){
    factorial = factorial*i;
}
console.log("The factorial is: "+factorial);
