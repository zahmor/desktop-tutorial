

let arr = ["one", "two", "three", "four", "five", "six", "seven", "eight", "nine"];
const input = require('readline-sync');
let num = input.question("Enter a number between 1 and 9 ");
console.log(arr[num-1].toUpperCase());