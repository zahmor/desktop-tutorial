let str = "";
str = str.concat("mos");
console.log(str);
