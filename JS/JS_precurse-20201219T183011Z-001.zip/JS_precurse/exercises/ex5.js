for(let i = 0; i<100; i+=1){
    if(i%2 !== 0){
        console.log(i + "\n");
    }
}