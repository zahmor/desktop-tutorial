const input = require('readline-sync');

let name = input.question("What is your name? ");
console.log("hello " + name + "!");
